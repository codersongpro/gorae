// 내 곳간 (작품을 기기에만 저장). backend: { getAll, get, put, delete } — 실제로는 IndexedDB.
export function createStore(backend, { now = () => new Date() } = {}) {
  return {
    list: async () => (await backend.getAll()).sort((a, b) => b.importedAt.localeCompare(a.importedAt)),
    get: (id) => backend.get(id),
    remove: (id) => backend.delete(id),
    put: (rec) => backend.put(rec), // 기존 기록 갱신(수정 저장)
    async markUsed(id) {
      const rec = await backend.get(id);
      if (!rec) return;
      await backend.put({ ...rec, lastUsedAt: now().toISOString(), useCount: (Number(rec.useCount) || 0) + 1 });
    },
    clear: async () => {
      for (const r of await backend.getAll()) await backend.delete(r.id);
    },
    // source: 'maker'(직접 만듦) | 'catalog'(인증 곳간) | 'bundle'(꾸러미) | 'link'(바로 실행 링크) | 'market'(나눔 곳간)
    // extra: 출처 정보 등 기록에 덧붙일 값 (예: 나눔 곳간에서 가져온 표시)
    async add(work, { source, checkReport, extra = {} }) {
      if (await backend.get(work.id)) return { ok: false, duplicate: true };
      const rec = { ...extra, id: work.id, work, source, importedAt: now().toISOString(), checkReport, favorite: false };
      await backend.put(rec);
      return { ok: true, record: rec };
    },
  };
}

export function createMemoryBackend() {
  const m = new Map();
  return {
    getAll: async () => [...m.values()].map((v) => structuredClone(v)),
    get: async (id) => (m.has(id) ? structuredClone(m.get(id)) : undefined),
    put: async (rec) => void m.set(rec.id, structuredClone(rec)),
    delete: async (id) => void m.delete(id),
  };
}
