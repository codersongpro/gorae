// 화면 컴포넌트 — 로직은 core/에서 받고, 여기서는 그리기만 한다.
import { h } from './dom.js';
import { S } from './strings.js';
import { displayBadge } from '../core/trust.js';
import { facetValues, metaOf, topTags } from '../core/filter.js';
import { KIND_OPTIONS } from '../shared/market.js';
import { isPopular } from '../shared/spout.js';
import { DOMAINS, categoriesOf, findCategory, GROUP_TYPES, TIME_OPTIONS, AUDIENCES, timeLabel, groupLabel, audienceLabel } from '../shared/taxonomy.js';
import { canRun } from '../core/runner.js';
import { isRestricted } from '../core/reference.js';
import { TOUR_STEPS } from './guide-steps.js';

const dateOnly = (iso) => String(iso || '').slice(0, 10);

function badgeEl(entry) {
  const b = displayBadge(entry);
  return h('span', { class: `badge ${b}` }, S.badge[b]);
}

// 검증 결과 한 줄: 통과하면 검수 서명 확인, 아니면 이유 (서명이 아예 없으면 이유 생략 가능)
function verifyLine(entry) {
  // 서명이 맞는 경우는 따로 표시하지 않는다(바다 배지와 고래 아이콘으로 충분). 서명이 있는데 문제가 있을 때만 이유를 보여 준다.
  const st = entry.status;
  if (st.ok || st.reason === 'NO_TAILPRINT') return null;
  // 서명이 있는데 맞지 않으면(변조·말소 등) 눈에 띄게: 맑은 바다 배지 대신 얕은 바다 + 이유
  return h('p', { class: 'notice error', role: 'status' }, `⚠️ ${S.reason[st.reason] || st.reason} ${S.bundle.notVerified}`);
}

function checkList(report) {
  if (!report) return null;
  if (report.ok) return h('p', { class: 'muted' }, `${S.detail.check}: ${S.detail.checkOk}`);
  return h('div', {}, h('p', { class: 'muted' }, S.detail.check),
    h('ul', { class: 'warn-list' }, report.warnings.map((w) => h('li', {}, `${w.label} — ${w.reason}`))));
}

// 빈 상태: 가운데 정렬 아이콘 + 제목 + (선택) 보조 버튼
export const emptyState = (title, { icon = '🐋', text = '', action = null } = {}) =>
  h('div', { class: 'empty' }, h('span', { class: 'icon', 'aria-hidden': 'true' }, icon), h('h3', {}, title),
    text ? h('p', {}, text) : null, action ? h('button', { onclick: action.onClick }, action.label) : null);

// 탭은 두 개: 곳간(인증 · 나눔은 위쪽 스위치로 전환) / 내 곳간
export function tabsBar(current, onSelect) {
  const tabs = [['catalog', ['catalog', 'market']], ['mypod', ['mypod']]];
  return h('div', { class: 'tabs two', role: 'tablist' },
    tabs.map(([k, set]) => h('button', { class: `tab ${k}`, role: 'tab', 'data-tour': `tab-${k}`, 'aria-selected': String(set.includes(current)), onclick: () => onSelect(k) }, S.tabs[k])));
}
// 인증 곳간 ↔ 나눔 곳간 전환 스위치
export const segSwitch = (current, onSwitch) => h('div', { class: 'seg', role: 'group', 'aria-label': S.seg.label },
  ['catalog', 'market'].map((k) => h('button', { type: 'button', 'data-tour': `seg-${k}`, 'aria-pressed': String(current === k), onclick: () => onSwitch(k) }, S.seg[k])));

export function topBar(mode, onToggle, onCreate, onImport, onGuide, onHome) {
  const teacher = mode === 'mother';
  return h('div', { class: 'top' },
    teacher ? h('div', { class: 'mode-band', role: 'status' }, S.mode.band) : null,
    h('header', { class: 'topbar' },
      h('div', { class: 'brand' },
        h('button', { class: 'brand-home', type: 'button', title: S.actions.home, 'aria-label': S.actions.home, onclick: onHome },
          h('span', { class: 'logo', 'aria-hidden': 'true' }, '🐳'),
          h('h1', {}, S.appName)),
        h('span', { class: `mode-label ${teacher ? 'teacher' : ''}` }, S.mode[mode])),
      h('div', { class: 'actions' },
        h('details', { class: 'add-menu' },
          h('summary', { class: 'icon-btn', 'data-tour': 'create', 'aria-label': S.actions.add2, title: S.actions.add2 }, '＋'),
          h('div', { class: 'menu-pop', role: 'menu' }, menuItem(S.actions.create, onCreate), menuItem(S.actions.import, onImport))),
        h('button', { class: 'icon-btn', 'data-tour': 'mode', 'aria-label': teacher ? S.mode.toggleToBaby : S.mode.toggleToMother, title: teacher ? S.mode.toggleToBaby : S.mode.toggleToMother, onclick: onToggle }, teacher ? '🔓' : '🔒'),
        onGuide ? h('button', { class: 'icon-btn', 'data-tour': 'guide', 'aria-label': S.guide.open, title: S.guide.open, onclick: onGuide }, '❔') : null)));
}

function select(label, value, options, onChange, labels = {}, allLabel = S.filter.all) {
  return h('label', {}, label,
    h('select', { onchange: (e) => onChange(e.target.value) },
      h('option', { value: '' }, allLabel),
      options.map((o) => {
        const id = typeof o === 'object' ? String(o.id) : o;
        const text = typeof o === 'object' ? o.label : labels[o] || o;
        return h('option', { value: id, selected: id === String(value || '') }, text);
      })));
}

// 찾기: 검색·학교급 칩·분류·정렬만 보이고, 나머지 조건은 [필터] 하나에 모은다
function findBar({ entries, state, onFilter, sortSel }) {
  const Fd = S.find;
  const cat = findCategory(state.domain, state.category);
  const q = h('input', { type: 'search', placeholder: Fd.search, 'aria-label': Fd.search, value: state.query || '' });
  q.addEventListener('change', () => onFilter({ query: q.value.trim() }));
  const tags = topTags(entries);
  // 분류: 수업/업무와 카테고리를 한 칸에 (수업 › 수업도구 …)
  const catSel = h('label', {}, Fd.categoryOne,
    h('select', { onchange: (e) => { const [d, c] = e.target.value.split('/'); onFilter({ domain: d || '', category: c || '', subcategory: '' }); } },
      h('option', { value: '' }, Fd.categoryAll),
      DOMAINS.map((d) => h('optgroup', { label: d.label }, categoriesOf(d.id).map((c) => h('option', { value: `${d.id}/${c.id}`, selected: state.domain === d.id && state.category === c.id }, c.label))))));
  const levels = [['', Fd.levelAll], ['elementary', '초'], ['middle', '중'], ['high', '고']];
  return h('div', { class: 'filters', 'data-tour': 'find' },
    h('div', { class: 'wide' }, q),
    h('div', { class: 'wide level-chips', role: 'group', 'aria-label': Fd.level },
      levels.map(([id, label]) => h('button', { type: 'button', class: 'chip', 'aria-pressed': String((state.schoolLevel || '') === id), onclick: () => onFilter({ schoolLevel: id }) }, label))),
    catSel,
    sortSel,
    h('details', { class: 'wide', open: state.moreOpen || null, ontoggle: (e) => { state.moreOpen = e.target.open; } },
      h('summary', {}, Fd.more),
      h('div', { class: 'filters' },
        cat ? select(cat.detail ? S.form.activityType : S.form.subcategory, state.subcategory, cat.subs, (v) => onFilter({ subcategory: v }), {}, Fd.subAll) : null,
        select(Fd.grade, state.grade, facetValues(entries, 'gradeLabel'), (v) => onFilter({ grade: v })),
        select(S.filter.subject, state.subject, facetValues(entries, 'subject'), (v) => onFilter({ subject: v })),
        select(Fd.time, state.maxMinutes, TIME_OPTIONS.map((t) => ({ id: t.minutes, label: t.label })), (v) => onFilter({ maxMinutes: v })),
        tags.length ? h('div', { class: 'row wide' }, h('span', { class: 'muted' }, Fd.tag),
          tags.map((t) => h('button', { class: state.tag === t ? 'chip primary' : 'chip', onclick: () => onFilter({ tag: state.tag === t ? '' : t }) }, '#' + t))) : null,
        h('button', { class: 'wide', onclick: () => onFilter({ query: '', domain: '', category: '', subcategory: '', schoolLevel: '', grade: '', subject: '', maxMinutes: '', tag: '' }) }, Fd.reset))));
}

// 지금 보고 있는 웨일 서비스에 맞춘 안내 띠 (클래스·팀보드·웨일온)
export function serviceBand({ service, label, mode, recommended = [], onGoTab, onRun, onFlow, hasFlow }) {
  if (!['class', 'teamboard', 'remote'].includes(service)) return null;
  const V = S.svc;
  const teacher = mode === 'mother';
  return h('div', { class: 'card svc-band', 'data-tour': 'svc-band' },
    h('p', {}, h('strong', {}, V.title(label))),
    h('p', { class: 'muted' }, V[service].text),
    service === 'class' ? h('div', { class: 'row' },
      h('button', { class: 'primary', onclick: () => onGoTab('mypod') }, V.class.go)) : null,
    service === 'teamboard' ? h('div', { class: 'row' }, h('button', { class: 'primary', onclick: () => onGoTab('mypod') }, V.teamboard.go)) : null,
    service === 'remote' ? h('div', { class: 'svc-rec' },
      recommended.length ? recommended.map((e) => h('div', { class: 'row' }, h('span', {}, e.work.title), h('button', { class: 'chip', disabled: !canRun(e).ok, onclick: () => onRun(e) }, S.actions.run)))
        : h('p', { class: 'muted' }, V.remote.none),
      teacher ? h('div', { class: 'row' }, h('button', { onclick: () => onGoTab('mypod') }, V.remote.flow), hasFlow ? h('button', { class: 'primary', onclick: onFlow }, V.remote.resume) : null) : null) : null);
}

// 수업 진행 화면: 도입 → 활동 → 정리 순서로 한 단계씩 실행한다
export function flowView({ steps, entries, i, onPrev, onNext, onRun, onBack, onJump }) {
  const F = S.flow;
  if (!steps.length) return h('section', { class: 'section' }, h('p', { class: 'notice' }, F.empty), h('button', { onclick: onBack }, S.actions.back));
  const cur = steps[i];
  const entry = entries[i];
  const total = steps.reduce((a, st) => a + st.minutes, 0);
  return h('section', { class: 'section flow' },
    h('div', { class: 'row' }, h('button', { onclick: onBack }, S.actions.back), h('h2', {}, F.title)),
    total ? h('p', { class: 'muted' }, F.total(total)) : null,
    h('ol', { class: 'flow-steps' }, steps.map((st, k) =>
      h('li', { class: k === i ? 'now' : k < i ? 'past' : '' },
        h('button', { type: 'button', 'aria-current': k === i ? 'step' : null, onclick: () => onJump(k) }, h('span', { class: 'lab' }, st.label), h('span', {}, st.work.title))))),
    h('div', { class: 'card' },
      h('p', { class: 'muted' }, `${cur.label} · ${i + 1} / ${steps.length}`),
      h('h3', {}, cur.work.title),
      cur.work.howToUse ? h('p', {}, cur.work.howToUse) : null,
      cur.minutes ? h('p', { class: 'muted' }, F.minutes(cur.minutes)) : null,
      h('div', { class: 'row' },
        h('button', { class: 'primary', disabled: !entry || !canRun(entry).ok, onclick: () => onRun(entry) }, S.actions.run),
        h('button', { onclick: onPrev, disabled: i === 0 }, F.prev),
        h('button', { onclick: onNext, disabled: i === steps.length - 1 }, F.next))));
}

// 곳간 구역 안내 띠: 인증 곳간(검수됨)과 나눔 곳간(검수 전)을 한눈에 구분한다
export const zoneBand = (kind) => h('div', { class: `zone ${kind}`, role: 'note' },
  h('strong', {}, S.zone[kind].title), h('span', {}, S.zone[kind].text));

// 카드 분류 뱃지: 카테고리(파랑) · 학년·교과·단원(청록) · 시간·모둠·대상(회색)
const pill = (kind, text) => h('span', { class: `pill ${kind}` }, text);
function metaLine(entry) {
  const m = metaOf(entry);
  const cat = m.path.slice(1).join(' › ');
  const edu = [[m.gradeLabel, m.subject].filter(Boolean).join(' '), m.unit ? `단원 ${m.unit}` : '', m.topic].filter(Boolean);
  const info = [timeLabel(m.estimatedMinutes), groupLabel(m.groupType), audienceLabel(m.audience)].filter(Boolean);
  return h('div', { class: 'card-meta' },
    h('div', { class: 'pills' },
      cat ? pill('cat', cat) : null, edu.map((t) => pill('edu', t)), info.map((t) => pill('info', t)),
      m.tags.map((t) => pill('tag', '#' + t))),
    m.artifactType === 'webapp' ? h('p', { class: 'notice' }, S.cardMeta.webapp) : null,
    m.artifactType === 'exe' ? h('p', { class: 'notice error' }, S.cardMeta.exe) : null);
}

// 검수된 작품은 🐋, 검수 전 작품은 범고래 🫍
export const VERIFIED_WHALE = '🐋';
export const UNVERIFIED_WHALE = '🫍';
// 제작자 줄: [고래 아이콘] 제작자 **닉네임** · 학교급 — 고래 아이콘은 검수 여부(그림 두 가지)만 알려 준다
export function makerLine(author, role, verified = false) {
  const [nick, ...rest] = String(author || '').split('·').map((t) => t.trim());
  if (!nick) return null;
  const sub = [rest.join(' · '), role].filter(Boolean).join(' · ');
  return h('p', { class: 'maker' }, h('span', { class: 'wi', role: 'img', 'aria-label': verified ? S.whaleIcon.ok : S.whaleIcon.no }, verified ? VERIFIED_WHALE : UNVERIFIED_WHALE),
    h('span', { class: 'maker-label' }, S.maker), h('strong', { class: 'nick' }, nick), sub ? h('span', { class: 'maker-sub' }, sub) : null);
}

// 이달의 고래자리 띠: 서명이 맞을 때만, 학생고래 모드에서는 맑은 바다 작품만
function featuredBand(entries, state, onRun) {
  const f = state.featured;
  if (!f || !f.ok || !f.items.length) return null;
  const byId = new Map(entries.map((e) => [e.work.id, e]));
  const shown = f.items.map((id) => byId.get(id)).filter((e) => e && (state.mode !== 'baby' || displayBadge(e) === 'clear'));
  if (!shown.length) return null;
  return h('div', { class: 'card featured' },
    h('p', {}, h('strong', {}, `🌟 ${f.title || S.featured.title}`), ' ', h('span', { class: 'muted' }, S.featured.hint)),
    f.note ? h('p', { class: 'muted' }, f.note) : null,
    shown.map((e) => h('div', { class: 'row' }, h('span', {}, e.work.title), h('button', { class: 'chip', disabled: !canRun(e).ok, onclick: () => onRun(e) }, S.actions.run))));
}

export function catalogView({ entries, visible, state, onFilter, onAdd, onRun, onToggleDetail, onRemix, share, submit, spout, sendBar, ui, top, onSwitch, mineIds = new Set(), onOpenMine }) {
  const sortSel = h('label', {}, S.filter.sort.label,
    h('select', { onchange: (e) => onFilter({ sort: e.target.value }) },
      ['new', 'spout'].map((k) => h('option', { value: k, selected: state.sort === k }, S.filter.sort[k]))));
  return h('section', { class: 'section' },
    segSwitch('catalog', onSwitch),
    zoneBand('catalog'),
    top || null,
    featuredBand(entries, state, onRun),
    sendBar || null,
    state.source !== 'network' || state.listRejected ? h('p', { class: 'notice' }, S.listState[state.source] + (state.listRejected ? ` · ${S.listState.listRejected}` : '')) : null,
    findBar({ entries, state, onFilter, sortSel }),
    listTools(visible.map((e) => e.work.id)),
    visible.length ? [...sliceOf(visible, ui).map((e) => workCard(e, { mode: state.mode, ui, onAdd, inMine: mineIds.has(e.work.id), onOpenMine, onRun, onToggleDetail, onRemix, share, submit, spout, open: state.openId === e.work.id })), moreButton(visible.length, sliceOf(visible, ui).length, ui)] : emptyState(S.empty.catalog, { icon: '🔍', action: onFilter ? { label: S.find.reset, onClick: () => onFilter({ query: '', domain: '', category: '', subcategory: '', grade: '', subject: '', audience: '', groupType: '', maxMinutes: '', badge: '', pickOnly: false, tag: '' }) } : null }));
}

// 학교급 뱃지: 학교급이 정해진 작품은 초/중/고 하나, 정해지지 않은(공통) 수업 작품은 초·중·고 모두
const LEVEL_BADGE = { elementary: ['초', 'e'], middle: ['중', 'm'], high: ['고', 'h'] };
function levelBadges(m) {
  if (m.domain !== 'lesson') return [];
  const ids = m.schoolLevel ? [m.schoolLevel] : ['elementary', 'middle', 'high'];
  return ids.map((id) => h('span', { class: `badge lvl lvl-${LEVEL_BADGE[id][1]}`, title: S.level.title(LEVEL_BADGE[id][0]) }, LEVEL_BADGE[id][0]));
}
// 카드 색은 세 가지: 수업자료(수업 작품) / 학급운영(수업도구·학급·생활) / 행정업무(그 밖의 업무)
export function cardGroup(domain, category) {
  if (domain === 'lesson') return category === 'classroom_tool' ? 'class' : 'material';
  return ['class_management', 'student_life'].includes(category) ? 'class' : 'admin';
}
// 시트에 적힌 주소가 구글 드라이브·문서 주소일 때만 링크로 만든다 (아무 사이트로나 보내지 않는다)
const DRIVE_HOSTS = ['drive.google.com', 'docs.google.com', 'drive.usercontent.google.com'];
const driveHref = (u) => { try { const x = new URL(u); return x.protocol === 'https:' && DRIVE_HOSTS.includes(x.hostname) ? x.href : ''; } catch { return ''; } };
const KIND_LABEL = { html: 'HTML', webapp: '웹앱', exe: 'EXE' };

// 목록 도구: 모두 펼치기/접기, 더 보기 (작품이 늘어도 길게 스크롤하지 않도록 기본은 접힌 카드 + 12개씩)
export const PAGE_SIZE = 12;
function listTools(ids) {
  if (ids.length < 2) return null;
  return h('div', { class: 'list-tools' }, h('span', { class: 'muted' }, S.list.count(ids.length)));
}
function moreButton(total, shown, ui) {
  if (!ui || !ui.onMore || shown >= total) return null;
  return h('button', { class: 'more-btn', onclick: ui.onMore }, S.list.more(total - shown));
}
const sliceOf = (items, ui) => (ui && ui.limit ? items.slice(0, ui.limit) : items);

// ⋯ 메뉴: 담기 말고 자주 쓰지 않는 동작(리믹스·수정·삭제·공유)을 한곳에 모은다
const menuItem = (label, fn, cls = '') => h('button', { type: 'button', role: 'menuitem', class: `menu-item ${cls}`.trim(), onclick: fn }, label);
function moreMenu(entry, { onEdit, onRemix, onRemove, share }) {
  const items = [];
  if (onRemix) items.push(menuItem(S.actions.remix, () => onRemix(entry)));
  if (onEdit) items.push(menuItem(S.actions.edit, () => onEdit(entry)));
  if (share) {
    items.push(h('p', { class: 'menu-group' }, S.share.menuTitle));
    if (share.onClassNow) items.push(menuItem(S.actions.classShare, () => share.onClassNow(entry), 'class-now'));
    if (share.onTeamboardNow) items.push(menuItem(S.share.teamboardNow, () => share.onTeamboardNow(entry), 'teamboard-now'));
    if (share.onWhaleonNow) items.push(menuItem(S.share.whaleonNow, () => share.onWhaleonNow(entry), 'whaleon-now'));
    for (const k of (share.kinds || []).filter((x) => x !== 'class' && x !== 'teamboard' && x !== 'space')) items.push(menuItem(S.share.kinds[k], () => share.onShare(entry, k)));
    items.push(menuItem(S.share.link, () => share.onLink(entry)));
    if (share.onAssessment) items.push(menuItem(S.share.ubt, () => share.onAssessment(entry), 'ubt-copy'));
  }
  if (onRemove) items.push(menuItem(S.actions.remove, () => onRemove(entry), 'danger'));
  if (!items.length) return null;
  return h('details', { class: 'more-menu' },
    h('summary', { 'aria-label': S.actions.more, title: S.actions.more }, '⋯'),
    h('div', { class: 'menu-pop', role: 'menu' }, ...items));
}

// EXE(실행형 프로그램) 정보: 고래곳간은 파일을 보관하지 않는다. 해시·소스·검사 결과·실행 환경을 보여 주고,
// 다운로드 링크는 교사고래 모드에서 검수 서명이 확인된(보류 아님) 항목에만 보인다.
function exeInfo(entry, mode) {
  const w = entry.work;
  const E = S.exe;
  const verified = entry.status.ok && entry.status.badge !== 'whirlpool';
  let href = '';
  try { const u = new URL(w.url); href = u.protocol === 'https:' ? u.href : ''; } catch { /* 아래에서 막는다 */ }
  return h('div', { class: 'notice error', role: 'note' },
    h('p', {}, h('strong', {}, E.warnTitle)), h('p', {}, E.warn),
    h('p', { class: 'muted' }, `SHA-256: ${w.sha256 || E.none}`),
    h('p', { class: 'muted' }, `${E.source}: ${w.sourceRepo || E.none}`),
    h('p', { class: 'muted' }, `${E.scan}: ${w.scanResult || E.none}`),
    h('p', { class: 'muted' }, `${E.env}: ${w.environment || E.none}`),
    mode === 'mother' && verified && href
      ? h('a', { class: 'btn', href, target: '_blank', rel: 'noopener noreferrer' }, E.download)
      : h('p', {}, verified ? E.teacherOnly : E.unverified));
}

function workCard(entry, opts) {
  const w = entry.work;
  // 참고 전용 작품은 학생고래 모드에서 보고 실행만 된다: 담기·리믹스·수정·꾸러미·레시피·공유를 숨긴다
  const locked = isRestricted(w, opts.mode);
  const { onRun, onToggleDetail, onRemove, open, report, extra, spout, fav, onFav, inMine, onOpenMine } = opts;
  const onAdd = locked ? null : opts.onAdd, onEdit = locked ? null : opts.onEdit, onRemix = locked ? null : opts.onRemix;
  const selectBox = locked ? null : opts.selectBox, share = locked ? null : opts.share, submit = locked ? null : opts.submit;
  const run = canRun(entry);
  const m = metaOf(entry);
  // 토글은 하나: 제목의 ▶를 누르면 설명·분류·사용 방법·점검 결과가 모두 펼쳐진다
  const more = !!open;
  const menu = moreMenu(entry, { onEdit, onRemix, onRemove: locked ? null : onRemove, share });
  return h('article', { class: `card${entry.status.ok ? ' verified-card' : ''}${more ? ' open' : ' compact'}`, 'data-group': cardGroup(m.domain, m.category) },
    h('div', { class: 'card-head' },
      h('button', { class: 'card-toggle', type: 'button', 'data-tour': 'details', 'aria-expanded': String(more), title: more ? S.list.fold : S.list.unfold, onclick: () => onToggleDetail(w.id) },
        h('span', { class: 'chev', 'aria-hidden': 'true' }, more ? '▼' : '▶'), h('h3', {}, w.title)),
      onFav ? h('button', { class: `star${fav ? ' on' : ''}`, type: 'button', 'aria-pressed': String(!!fav), 'aria-label': fav ? S.fav.off : S.fav.on, title: fav ? S.fav.off : S.fav.on, onclick: () => onFav(entry) }, fav ? '★' : '☆') : null),
    h('div', { class: 'row', 'data-tour': 'badge' }, ...levelBadges(m), badgeEl(entry), entry.status.ok && entry.status.pick ? h('span', { class: 'badge pick' }, S.pick) : null,
      w.referenceOnly === true ? h('span', { class: 'badge reference' }, S.reference.badge) : null,
      KIND_LABEL[m.artifactType] ? h('span', { class: 'pill info' }, KIND_LABEL[m.artifactType]) : null,
      spout && isPopular(spout.countsOf(entry)) ? h('span', { class: 'badge popular', title: S.popular.hint }, S.popular.badge) : null),
    makerLine(w.author, '', !!entry.status.ok),
    locked ? h('p', { class: 'notice' }, S.reference.cardNote) : null,
    selectBox || null,
    more && m.description ? h('p', { class: 'desc' }, m.description) : null,
    more ? metaLine(entry) : null,
    verifyLine(entry), // 서명 문제는 접힌 카드에서도 보인다
    more && w.remixOf ? h('p', { class: 'muted' }, '🔄 ' + S.lineage(w.remixOfTitle || w.remixOf)) : null,
    more ? extra || null : null,
    h('div', { class: 'card-actions' },
      spout ? spoutRow(entry, spout) : null,
      h('span', { class: 'spacer' }),
      onAdd ? (inMine
        ? h('button', { class: 'in-mine', title: S.actions.addedHint, onclick: () => onOpenMine(entry) }, S.actions.added)
        : h('button', { onclick: () => onAdd(entry) }, S.actions.add)) : null,
      menu,
      h('button', { class: 'primary', 'data-tour': 'run', disabled: !run.ok, onclick: () => onRun(entry) }, S.actions.run)),
    !run.ok ? h('p', { class: 'muted' }, S.run[run.reason]) : null,
    open ? h('div', { class: 'detail' },
      m.artifactType === 'exe' ? exeInfo(entry, opts.mode) : null,
      m.standard ? h('p', { class: 'muted' }, `성취기준: ${m.standard}`) : null,
      h('div', {}, h('p', { class: 'muted' }, S.detail.howTo), h('p', {}, w.howToUse)),
      w.promptRecipe && !locked ? h('div', {}, h('p', { class: 'muted' }, S.detail.recipe), h('pre', {}, w.promptRecipe)) : null,
      entry.status.ok && entry.status.songs.length ? entry.status.songs.map((s) => h('p', {}, `🎤 ${s.text} — ${s.author}`)) : null,
      checkList(report),
      submit ? submitPanel(entry, { ...submit, draft: submit.draftOf ? submit.draftOf(entry) : null }) : null) : null);
}

// 물뿜기: 교사·학생 숫자를 그대로 보여 주고, 기기당 한 번 누를 수 있다
// 좋아요처럼: 누르면 🐳 뿜었어요(숫자 +1), 아직 보내기 전이면 다시 눌러 취소. 보낸 뒤에는 고정.
function spoutRow(entry, { countsOf, mineOf, onSpout }) {
  const c = countsOf(entry);
  const mine = mineOf(entry);
  return h('div', { class: 'spout', 'data-tour': 'spout' },
    h('button', {
      'aria-pressed': String(!!mine), title: S.spout.hint, 'aria-label': `${mine ? S.spout.done : S.spout.button} ${S.spout.counts(c.teacher, c.student)}`,
      onclick: () => onSpout(entry),
    }, h('span', { class: 'emoji', 'aria-hidden': 'true' }, mine ? '🐳' : '🐋'), ' ', mine ? S.spout.done : S.spout.button, ' ', S.spout.counts(c.teacher, c.student)));
}

// 보내지 않은 물뿜기 띠
export function spoutSendBar({ pending, waiting, onSend, onSent }) {
  if (!pending && !waiting) return null;
  return h('div', { class: 'notice' },
    h('p', {}, S.spout.pending(pending)),
    h('div', { class: 'row' },
      h('button', { onclick: onSend }, S.spout.send),
      waiting ? h('button', { class: 'primary', onclick: onSent }, S.spout.sent) : null));
}

// 인증 곳간에 보내기 (교사고래 모드에서만 만들어진다): 개인정보 확인 → 설문 문항별 답·업로드 파일 → 구글 설문 열기
function submitPanel(entry, { allowRecommend, draft, profile, ready, onPrepare, onCopy, onSaveFile, onOpenForm, showSong, onSong }) {
  const Sb = S.submit;
  const nick = h('input', { 'aria-label': Sb.nickname, placeholder: Sb.nickname, value: (draft && draft.nickname) || (profile && profile.nickname) || '' });
  const privacy = h('input', { type: 'checkbox', checked: !!draft });
  const song = h('input', { 'aria-label': Sb.songLabel, placeholder: Sb.songLabel, maxlength: '120' });
  const pkg = draft && draft.result;
  const row = (label, value) => (value ? h('div', { class: 'field' }, h('span', {}, label),
    h('div', { class: 'row' }, h('span', {}, value), h('button', { class: 'chip', onclick: () => onCopy(value) }, Sb.copy))) : null);
  return h('div', { class: 'detail' },
    h('p', { class: 'muted' }, Sb.title),
    allowRecommend ? h('div', { class: 'section' },
      nick,
      h('label', { class: 'check' }, privacy, Sb.privacy),
      h('button', { onclick: () => onPrepare(entry, { nickname: nick.value, privacyChecked: privacy.checked }) }, Sb.prepare)) : null,
    pkg ? h('div', { class: 'card' },
      pkg.file ? h('button', { onclick: () => onSaveFile(pkg.file) }, Sb.step1(pkg.file.name)) : h('p', { class: 'muted' }, Sb.noFile),
      ready ? h('button', { class: 'primary', onclick: () => onOpenForm(pkg) }, Sb.step2) : h('p', { class: 'notice' }, Sb.notReady),
      ready ? null : Object.entries(pkg.prefill).map(([k, v]) => row(Sb.field[k] || k, v)),
      h('p', { class: 'muted' }, Sb.step3),
      (pkg.warnings || []).map((w) => h('p', { class: 'notice' }, w))) : null,
    showSong ? h('div', { class: 'section' }, song, h('button', { onclick: () => onSong(entry, { text: song.value, author: nick.value, privacyChecked: privacy.checked }) }, Sb.song)) : null);
}

// 나눔 곳간: 시트 목록 → 검색·분류 거르기 → 가져오기
export function marketView({ m, onRefresh, onFilter, onImport, onPreview, onReview, onSwitch, mode = 'baby', spout, sendBar, web = false, ui }) {
  const M = S.market;
  const q = h('input', { type: 'search', placeholder: S.find.search, 'aria-label': S.find.search, value: m.query || '' });
  q.addEventListener('change', () => onFilter({ query: q.value.trim() }));
  const shown = (m.entries || []).filter((e) => {
    if (m.kind && !e.kinds.includes(m.kind)) return false;
    if (!m.query) return true;
    const hay = [e.title, e.description, e.nickname, e.comment, e.categoryText, ...e.kinds].join(' ').toLowerCase();
    return m.query.toLowerCase().split(/\s+/).every((t) => hay.includes(t));
  });
  let state = null;
  if (m.status === 'loading') state = h('p', { class: 'notice' }, M.loading);
  else if (m.status === 'error') state = h('p', { class: 'notice error', role: 'alert' }, M.error[m.error] || m.error);
  else if (m.missing && m.missing.length) state = h('p', { class: 'notice error' }, M.columns(m.missing, m.header || []));
  const teacher = mode === 'mother';
  const isEx = (id) => !!(ui && ui.expanded && ui.expanded[id]);
  return h('section', { class: 'section' },
    segSwitch('market', onSwitch),
    zoneBand('market'),
    sendBar || null,
    h('div', { class: 'filters' },
      h('label', { class: 'wide' }, S.find.search, q),
      select(S.market.kind, m.kind, KIND_OPTIONS, (v) => onFilter({ kind: v }), {}, S.filter.all),
      h('button', { class: 'wide', onclick: onRefresh }, M.refresh)),
    state,
    m.source === 'cache' ? h('p', { class: 'notice' }, M.cache) : null,
    m.notice ? h('p', { class: 'notice' }, m.notice) : null,
    m.status === 'ok' && !(m.entries || []).length ? h('p', { class: 'muted' }, M.empty) : null,
    m.status === 'ok' && (m.entries || []).length ? h('p', { class: 'muted' }, M.count(shown.length)) : null,
    m.status === 'ok' && (m.entries || []).length && !shown.length ? h('p', { class: 'muted' }, M.none) : null,
    listTools(shown.map((e) => e.id)),
    sliceOf(shown, ui).map((e) => h('article', { class: `card market-card${ui && ui.expanded && ui.expanded[e.id] ? ' open' : ' compact'}`, 'data-group': cardGroup(e.category && e.category.domain, e.category && e.category.category) },
      h('div', { class: 'card-head' }, h('button', { class: 'card-toggle', type: 'button', 'aria-expanded': String(!!(ui && ui.expanded && ui.expanded[e.id])), onclick: () => ui && ui.onExpand && ui.onExpand(e.id) },
        h('span', { class: 'chev', 'aria-hidden': 'true' }, ui && ui.expanded && ui.expanded[e.id] ? '▼' : '▶'), h('h3', {}, e.title))),
      makerLine(e.nickname, e.whale, false),
      h('div', { class: 'row' }, h('span', { class: 'badge precheck' }, S.zone.market.badge), h('span', { class: 'badge shallow' }, S.badge.shallow), spout && isPopular(spout.countsOf({ work: { id: e.id } })) ? h('span', { class: 'badge popular', title: S.popular.hint }, S.popular.badge) : null, e.sample ? h('span', { class: 'badge' }, M.sampleTag) : null),
      isEx(e.id) && (e.kinds.length || e.categoryText) ? h('div', { class: 'pills' }, e.kinds.map((k) => pill('cat', k)), e.categoryText ? pill('info', e.categoryText) : null) : null,
      teacher && spout && isPopular(spout.countsOf({ work: { id: e.id } })) ? h('p', { class: 'notice' }, S.popular.reviewTip) : null,
      isEx(e.id) && e.timestamp ? h('p', { class: 'muted' }, e.timestamp) : null,
      isEx(e.id) && e.description ? h('p', {}, e.description) : null,
      isEx(e.id) && e.comment ? h('p', { class: 'muted' }, '💬 ' + e.comment) : null,
      isEx(e.id) && !(e.files.length || e.payload) ? h('p', { class: 'muted' }, S.cardMeta.webapp) : null,
      spout ? spoutRow({ work: { id: e.id } }, spout) : null,
      // 웹 버전: 구글 드라이브 파일은 브라우저가 직접 받을 수 없어 드라이브에서 열어 보게 한다 (가져오기는 웨일 사이드바에서)
      web && e.files.length
        ? h('div', {}, h('p', { class: 'muted' }, M.webFileNote),
          !driveHref(e.files[0]) ? h('p', { class: 'notice error' }, M.badLink) : h('a', { class: 'btn', href: driveHref(e.files[0]), target: '_blank', rel: 'noopener noreferrer' }, M.openInDrive))
        : h('div', { class: 'row' },
          // 미리 보기: 내 곳간에 담지 않고 바로 새 창에서 연다
          h('button', { disabled: !!(m.busy && m.busy[e.id]), onclick: () => onPreview(e) }, M.preview),
          teacher ? h('button', { class: 'primary', disabled: !!(m.busy && m.busy[e.id]) || !!(m.done && m.done[e.id]), onclick: () => onImport(e) },
            m.done && m.done[e.id] ? M.imported : m.busy && m.busy[e.id] ? M.importing : M.import) : null,
          teacher ? h('button', { class: spout && isPopular(spout.countsOf({ work: { id: e.id } })) ? 'primary' : '', disabled: !!(m.busy && m.busy[e.id]), title: M.reviewHint, onclick: () => onReview(e) }, M.review) : null,
          !teacher ? h('p', { class: 'muted' }, M.studentNote) : null))),
    moreButton(shown.length, sliceOf(shown, ui).length, ui));
}

// 나눔 곳간 작품을 실행하기 전 출처 확인
export function marketRunConfirm({ title, onRun, onCancel }) {
  const M = S.market;
  return h('section', { class: 'section' },
    h('div', { class: 'card', role: 'alertdialog', 'aria-label': M.runTitle },
      h('h3', {}, M.runTitle),
      h('p', {}, h('strong', {}, title)),
      h('p', {}, M.runBody),
      h('div', { class: 'row' }, h('button', { class: 'primary', onclick: onRun }, M.runOk), h('button', { onclick: onCancel }, M.runCancel))));
}

// 웨일 스페이스 공유 버튼 묶음: 지금 화면의 서비스에 맞는 버튼이 맨 앞에 온다
// 선택 바: 내 곳간에서 작품을 체크하면 아래에 뜬다 (꾸러미·클래스·팀보드·수업 진행을 한곳에서)
function selectBar({ count, teacher, bar }) {
  const T = S.sel;
  return h('div', { class: 'select-bar', role: 'region', 'aria-label': T.label },
    h('div', { class: 'select-inner' },
      h('strong', {}, T.count(count)),
      h('details', { class: 'more-menu up', 'data-tour': 'select-share' },
        h('summary', { 'aria-label': T.share }, T.share + ' ▲'),
        h('div', { class: 'menu-pop', role: 'menu' },
          menuItem(T.pack, bar.onPack),
          menuItem(T.class, bar.onClass), // 학생고래도 쓸 수 있다
          menuItem(T.teamboard, bar.onTeamboard),
          menuItem(T.whaleon, bar.onWhaleon))),
      teacher ? h('button', { class: 'primary', 'data-tour': 'flow-start', title: T.flowHint, onclick: bar.onFlow }, T.flow) : null,
      h('button', { onclick: bar.onClear }, T.clear)));
}

export function mypodView({ records, entriesById, state, onRun, onRemove, onToggleDetail, onEdit, onRemix, onSelect, share, submit, onSearch, total, ui, onFav, onFavOnly, top, bar }) {
  const q = h('input', { type: 'search', placeholder: S.find.search, 'aria-label': S.find.search, value: state.mypodQuery || '' });
  q.addEventListener('change', () => onSearch(q.value.trim()));
  const selected = state.selected || [];
  return h('section', { class: `section${selected.length ? ' has-bar' : ''}` },
    top || null,
    total ? h('label', { class: 'field' }, h('span', {}, S.find.search), q) : null,
    state.mypodQuery ? h('p', { class: 'muted' }, S.find.found(records.length, total)) : null,
    total ? h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: !!state.favOnly, onchange: (e) => onFavOnly(e.target.checked) }), S.fav.only) : null,
    listTools(records.map((r) => r.id)),
    records.length ? [...sliceOf(records, ui).map((r) => {
      const w = r.work;
      const tags = [`출처: ${S.source[r.source] || r.source}`, `버전 ${w.version}`];
      if (r.sample) tags.unshift(S.market.sampleTag);
      if (w.editedFrom) tags.push(`${S.edit.editedFrom} (원본 ${w.editedFrom})`);
      if (r.checkReport && !r.checkReport.ok) tags.push(`점검 경고 ${r.checkReport.warnings.length}개`);
      return workCard(entriesById.get(r.id), {
        mode: state.mode, ui, fav: !!r.favorite, onFav, onRun, onRemove, onToggleDetail, onEdit, onRemix, share, submit, open: state.openId === r.id, report: r.checkReport,
        selectBox: h('label', { class: 'check' },
          h('input', { type: 'checkbox', checked: selected.includes(r.id), onchange: (e) => onSelect(r.id, e.target.checked) }), S.sel.pick),
        extra: h('p', { class: 'muted' }, tags.join(' · ')),
      });
    }), moreButton(records.length, sliceOf(records, ui).length, ui)] : state.mypodQuery ? null : emptyState(S.empty.mypodTitle, { icon: '🐋', text: S.empty.mypod }),
    selected.length ? selectBar({ count: selected.length, teacher: state.mode === 'mother', bar }) : null);
}

export function runView({ entry, onBack, onOpenTab }) {
  const w = entry.work;
  const frame = h('iframe', { src: 'sandbox.html', title: w.title });
  return {
    frame,
    el: h('div', { class: 'runview' },
      h('div', { class: 'bar' },
        h('button', { onclick: onBack }, S.actions.back),
        h('div', {}, h('strong', {}, w.title), h('p', { class: 'muted' }, S.run.running))),
      frame),
  };
}

export function importView({ preview, errors, onCheck, onToggle, selected, onConfirm, onCancel }) {
  const text = h('textarea', { 'aria-label': S.bundle.pasteLabel, placeholder: S.bundle.pasteLabel });
  const file = h('input', { type: 'file', accept: '.json,.txt,application/json,text/plain' });
  file.addEventListener('change', async () => { const f = file.files[0]; if (f) text.value = await f.text(); });
  return h('section', { class: 'section' },
    h('h2', {}, S.bundle.importTitle),
    h('p', { class: 'muted' }, S.bundle.importHint),
    file, text,
    h('div', { class: 'row' }, h('button', { class: 'primary', onclick: () => onCheck(text.value) }, S.bundle.check), h('button', { onclick: onCancel }, S.actions.back)),
    errors && errors.length ? h('div', { class: 'notice error', role: 'alert' }, errors.map((e) => h('p', {}, e.index === undefined ? e.message : `${e.index + 1}번째 작품: ${e.message}`))) : null,
    preview ? h('div', { class: 'section' },
      h('h3', {}, S.bundle.previewTitle(preview.name, preview.items.length)),
      h('p', { class: 'muted' }, S.bundle.pickWorks),
      preview.items.map((it) => {
        const entry = { work: it.work, status: it.status };
        return h('article', { class: 'card' },
          h('label', { class: 'check' }, h('input', { type: 'checkbox', disabled: it.duplicate, checked: selected.includes(it.work.id), onchange: (e) => onToggle(it.work.id, e.target.checked) }), h('strong', {}, it.work.title)),
          badgeEl(entry),
          h('p', { class: 'muted' }, `${it.work.grade || ''} · ${it.work.subject || ''} · ${it.work.author || ''}`),
          it.status.ok ? verifyLine(entry) : h('p', { class: 'muted' }, `${S.reason[it.status.reason] || it.status.reason} → ${S.bundle.notVerified}`),
          it.duplicate ? h('p', { class: 'muted' }, S.bundle.dup) : null,
          checkList(it.report));
      }),
      h('button', { class: 'primary', onclick: onConfirm }, S.bundle.confirm)) : null);
}

// 외부 사이트(URL 작품)를 열기 전 확인 카드 — 사용자가 [새 탭에서 열기]를 눌러야 열린다
export function urlConfirmView({ info, onOpen, onCancel }) {
  return h('section', { class: 'section' },
    h('div', { class: 'card', role: 'alertdialog', 'aria-label': S.run.confirmTitle },
      h('h3', {}, S.run.confirmTitle),
      h('p', {}, S.run.confirmHost(info.host)),
      info.verified ? null : h('p', { class: 'notice error' }, S.run.confirmUnverified),
      h('p', { class: 'muted' }, info.url),
      h('div', { class: 'row' },
        h('button', { class: 'primary', onclick: onOpen }, S.run.confirmOpen),
        h('button', { onclick: onCancel }, S.run.confirmCancel))));
}

// 교사고래 암호 화면: 처음이면 정하기, 아니면 넣기
export function pinView({ hasPin, error, askReset, onSet, onEnter, onCancel, onForgot, onReset }) {
  const P = S.pin;
  let first = ''; // 정하기 1단계에서 입력한 암호
  let step = hasPin ? 'enter' : 'set1';
  let digits = '';
  const root = h('section', { class: 'section pin' });
  const MAX = 8;
  const dots = () => h('div', { class: 'pin-dots', 'aria-label': `${digits.length}자리 입력됨` }, Array.from({ length: Math.max(4, digits.length) }, (_, k) => h('i', { class: k < digits.length ? 'on' : '' })));
  const confirm = () => {
    if (digits.length < 4) return;
    if (step === 'enter') return onEnter(digits);
    if (step === 'set1') { first = digits; digits = ''; step = 'set2'; return draw(); }
    return onSet(first, digits);
  };
  const press = (d) => { if (digits.length < MAX) { digits += d; draw(); } };
  const back = () => { digits = digits.slice(0, -1); draw(); };
  function draw() {
    const title = step === 'enter' ? P.enterTitle : step === 'set1' ? P.setTitle : P.confirmTitle;
    const keys = ['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((d) => h('button', { onclick: () => press(d), 'aria-label': d }, d));
    root.replaceChildren(...[
      h('h2', {}, title),
      h('p', { class: 'muted' }, step === 'enter' ? P.enterHint : P.setHint),
      error ? h('p', { class: 'notice error', role: 'alert' }, error) : null,
      dots(),
      h('div', { class: 'keypad' }, ...keys,
        h('button', { class: 'text', onclick: back }, P.erase),
        h('button', { onclick: () => press('0'), 'aria-label': '0' }, '0'),
        h('button', { class: 'text primary', disabled: digits.length < 4, onclick: confirm }, P.ok)),
      h('div', { class: 'row' }, h('button', { onclick: onCancel }, P.cancel),
        hasPin && !askReset ? h('button', { onclick: onForgot }, P.forgot) : null),
      askReset ? h('div', { class: 'notice' }, h('p', {}, P.forgotConfirm), h('button', { class: 'danger', onclick: onReset }, P.reset)) : null,
    ].filter(Boolean)); // replaceChildren는 null을 글자 "null"로 넣으므로 걸러 낸다
  }
  // 키보드로도 입력할 수 있게 한다
  root.tabIndex = -1;
  root.addEventListener('keydown', (e) => {
    if (/^\d$/.test(e.key)) press(e.key);
    else if (e.key === 'Backspace') back();
    else if (e.key === 'Enter') confirm();
  });
  draw();
  setTimeout(() => root.focus(), 0);
  return root;
}

// 사용 방법 화면: 등급(역할)·배지·표시 읽는 법을 한 곳에 모으고, 따라 해보기 버튼을 둔다
export function guideView({ onStartTour, onBack, onCopy, web = false }) {
  const G = S.guide;
  const sec = (title, ...kids) => h('section', { class: 'card guide-sec' }, h('h3', {}, title), ...kids.filter(Boolean));
  // 웨일 사이드바 설치 (웹 버전에서는 맨 위): 링크는 눌러서 열고, whale:// 주소는 복사 버튼을 쓴다
  const installSec = () => h('section', { class: 'card guide-sec install-sec', 'data-tour': 'install' },
    h('h3', {}, G.web.installTitle), h('p', { class: 'lead' }, G.web.installIntro),
    h('button', { class: 'primary', 'data-tour': 'install-start', onclick: () => onStartTour('install') }, G.web.startInstall),
    h('ol', { class: 'install-steps' }, G.web.installSteps.map((st, i) => h('li', { 'data-tour': `inst-${i + 1}` },
      h('p', {}, st.text),
      st.links || st.copy ? h('div', { class: 'row' },
        (st.links || []).map((l) => h('a', { class: 'btn', href: l.href, target: '_blank', rel: 'noopener noreferrer' }, l.label)),
        st.copy ? h('button', { type: 'button', onclick: () => onCopy(st.copy) }, st.copyLabel) : null) : null))),
    h('p', { class: 'muted' }, G.web.installNote));
  return h('section', { class: 'section guide' },
    h('div', { class: 'row' }, h('button', { onclick: onBack }, S.actions.back), h('h2', {}, G.title)),
    web ? installSec() : null,
    h('div', { class: 'card guide-hero' }, h('p', {}, G.intro), h('div', { class: 'row' }, h('button', { class: 'primary', 'data-tour': 'guide-start', onclick: () => onStartTour('main') }, G.start))),
    ...G.sections.map((sc) => sec(sc.title,
      sc.intro ? h('p', { class: 'muted' }, sc.intro) : null,
      sc.rows ? h('div', { class: 'guide-rows' }, sc.rows.map((r) => h('div', { class: 'guide-row' },
        r.badges ? h('span', { class: 'guide-badges' }, r.badges.map(([l, c]) => h('span', { class: `badge ${c}` }, l))) : h('span', { class: `badge ${r.cls || ''}`.trim() }, r.label), r.text ? h('p', {}, r.text) : null))) : null,
      sc.items ? h('ul', { class: 'guide-list' }, sc.items.map((t) => h('li', {}, t))) : null)),
    web ? null : sec(G.web.goTitle,
      h('p', {}, G.web.goIntro),
      h('p', {}, h('a', { class: 'btn', href: G.web.url, target: '_blank', rel: 'noopener noreferrer' }, G.web.goBtn)),
      h('p', { class: 'muted' }, G.web.goNote)),
    h('p', { class: 'muted' }, G.stepsCount(TOUR_STEPS.length)));
}
